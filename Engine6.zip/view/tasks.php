<head>
    <meta charset="UTF-8">
    <title>Главная</title>
</head>
<body>

<?php include "menu.php" ?>

Задачи циклом

<?php foreach ($tasks as $task):?>
    <div>
        <?=$task?> [Done]
    </div>
<?php endforeach;?>


</body>