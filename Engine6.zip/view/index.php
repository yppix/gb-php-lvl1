<head>
    <meta charset="UTF-8">
    <title>Главная</title>
</head>
<body>

<?php include "menu.php" ?>
<h1><?= $pageHeader ?></h1>
</body>